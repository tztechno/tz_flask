
import datetime as dt
import pytz
from datetime import date, time, timedelta
from flask import Flask
from flask import render_template
from jinja2 import Environment, PackageLoader, select_autoescape

app = Flask(__name__)

gm0='回収なし'
gm1='小型不燃ごみ'
gm2='ペットボトル'
gm3='かん・びん'
gm4='紙・布'
gm5='プラスチック類'
gm6='燃やすごみ'

jyobi=['月曜日','火曜日','水曜日','木曜日','金曜日','土曜日','日曜日',]
GOM=[gm5,gm5,gm5,gm5,gm5,gm6,gm6,gm6,gm6,gm6,gm1,gm3,gm1,gm3,gm0,gm4,gm2,gm4,gm2,gm0,gm6,gm6,gm6,gm6,gm6,gm0,gm0,gm0,gm0,gm0,gm0,gm0,gm0,gm0,gm0,]
N=list(range(35))
normal_mapping=dict(zip(N,GOM)) 

now = dt.datetime.now(pytz.timezone('Asia/Tokyo'))
dayidx = now.weekday()

dayofwkj0=jyobi[dayidx]
today = dt.datetime.date(now)

dayofwkj1=jyobi[(dayidx+1)%7]
tomorrow=today+dt.timedelta(1)

def dateth(date):
    day=int(str(date).split('-')[-1])
    th=(day-1)//7+1
    return th

num0=dayidx*5+dateth(today)-1
todayG=normal_mapping[num0]

num1=(dayidx+1)*5+dateth(tomorrow)-1
tomorrowG=normal_mapping[num1]

@app.route("/")
def trash():
    return render_template('trash.html', today=today, dayofwkj0=dayofwkj0, todayG=todayG,tomorrow=tomorrow, dayofwkj1=dayofwkj1, tomorrowG=tomorrowG,)

